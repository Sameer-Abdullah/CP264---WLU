var main_8c =
[
    [ "MAX_LINE", "main_8c.htm#a842ed03f27719bc87666bfd1f75415b8", null ],
    [ "NAME_LEN", "main_8c.htm#a4853f6c25c8394fd57c4d99f61d5cd89", null ],
    [ "main", "main_8c.htm#a0ddf1224851353fc92bfbff6f499fa97", null ]
];