/**
 * -------------------------------------
 * @file  graph_am.c
 * Adjacency Matrix Graph Code File
 * -------------------------------------
 * @author Sameer Abdullah, 169065039, abdu5039@mylaurier.ca
 *
 * @version 2025-01-06
 *
 * -------------------------------------
 */
#include "graph_am.h"

// Initializes an adjacency matrix graph.
graph_am* graph_am_initialize(int size) {
	graph_am *source = malloc(sizeof *source);
	source->size = size;
	// Initialize values to zeroes.
	source->values = calloc(size * size, sizeof *source->values);
	return source;
}

void graph_am_free(graph_am **source) {
	// Free up the data array.
	free((*source)->values);
	(*source)->values = NULL;
	free(*source);
	*source = NULL;
	return;
}

int graph_am_add_vertice(graph_am *source, const graph_am_pair *pair) {
	int added = 0;

	if (pair->row < 0 || pair->row >= source->size)
		return added;
	if (pair->col < 0 || pair->col >= source->size)
		return added;

	int *matrix = source->values;

	if (pair->row == pair->col) {
		if (*(matrix + pair->row * source->size + pair->col) == 0) {
			*(matrix + pair->row * source->size + pair->col) = 2;
			added = 1;
		}
	} else {
		if (*(matrix + pair->row * source->size + pair->col) == 0) {
			*(matrix + pair->row * source->size + pair->col) = 1;
			*(matrix + pair->col * source->size + pair->row) = 1;
			added = 1;
		}
	}

	return added;
}

int graph_am_remove_vertice(graph_am *source, const graph_am_pair *pair) {
	int removed = 0;

	if (pair->row < 0 || pair->row >= source->size)
		return removed;
	if (pair->col < 0 || pair->col >= source->size)
		return removed;

	int *matrix = source->values;

	if (*(matrix + pair->row * source->size + pair->col) != 0) {
		*(matrix + pair->row * source->size + pair->col) = 0;
		if (pair->row != pair->col) {
			*(matrix + pair->col * source->size + pair->row) = 0;
		}
		removed = 1;
	}
	return removed;
}

graph_am* graph_am_create(int size, const graph_am_pair pairs[], int count) {
	graph_am *source = graph_am_initialize(size);

	for (int i = 0; i < count; i++) {
		graph_am_add_vertice(source, &pairs[i]);
	}
	return source;
}

void graph_am_neighbours(const graph_am *source, int vertex, int vertices[],
		int *count) {

	*count = 0;

	if (vertex < 0 || vertex >= source->size)
		return;

	for (int i = 0; i < source->size; i++) {
		int val = *(source->values + vertex * source->size + i);
		if (val > 0) {
			vertices[*count] = i;
			(*count)++;
		}
	}
	return;
}

int graph_am_degree(const graph_am *source, int vertex) {
	int connected = 0;

	if (vertex < 0 || vertex >= source->size)
		return connected;

	for (int i = 0; i < source->size; i++) {
		int val = *(source->values + vertex * source->size + i);
		if (i == vertex && val == 2) {
			connected += 2; // loop counts as 2
		} else if (val > 0) {
			connected++;
		}
	}
	return connected;
}

void graph_am_breadth_traversal(const graph_am *source, int vertex,
		int vertices[], int *count) {

	int visited[source->size];
	for (int i = 0; i < source->size; i++)
		visited[i] = 0;

	int queue[source->size];
	int front = 0, rear = 0;

	*count = 0;

	queue[rear++] = vertex;
	visited[vertex] = 1;

	while (front < rear) {
		int current = queue[front++];
		vertices[(*count)++] = current;

		for (int i = 0; i < source->size; i++) {  // smaller indices first
			if (*(source->values + current * source->size + i) > 0
					&& !visited[i]) {
				queue[rear++] = i;
				visited[i] = 1;
			}
		}
	}

	return;
}

void graph_am_depth_traversal(const graph_am *source, int vertex,
		int vertices[], int *count) {

	int visited[source->size];
	for (int i = 0; i < source->size; i++)
		visited[i] = 0;

	int stack[source->size];
	int top = -1;

	*count = 0;

	stack[++top] = vertex;

	while (top >= 0) {
		int current = stack[top--];

		if (!visited[current]) {
			visited[current] = 1;
			vertices[(*count)++] = current;

			//  Push higher index neighbors first
			for (int i = source->size - 1; i >= 0; i--) {
				int val = *(source->values + current * source->size + i);
				if (val > 0 && !visited[i]) {
					stack[++top] = i;
				}
			}
		}
	}
	return;
}

// Prints the contents of an adjacency matrix graph.
void graph_am_print(const graph_am *source) {
// Print the column numbers.
	printf("    ");

	for (int i = 0; i < source->size; i++)
		printf("%3d", i);
	printf("\n");
	printf("    ");
	for (int i = 0; i < source->size; i++)
		printf("---");
	printf("\n");

// Print the row numbers and rows.
	for (int i = 0; i < source->size; i++) {
		printf("%3d|", i);

		for (int j = 0; j < source->size; j++) {
			// find item using offsets
			printf("%3d", *(source->values + i * source->size + j));
		}
		printf("\n");
	}
}
