var annotated_dup =
[
    [ "name_set", "structname__set.htm", "structname__set" ],
    [ "NAME_SET_NODE", "struct_n_a_m_e___s_e_t___n_o_d_e.htm", "struct_n_a_m_e___s_e_t___n_o_d_e" ]
];