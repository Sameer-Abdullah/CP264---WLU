/**
 * -------------------------------------
 * @file  strings_with_substring.c
 * Lab 4 Source Code File
 * -------------------------------------
 * @author Sameer Abdullah, 169065039, abdu5039@mylaurier.ca
 *
 * @version 2025-02-02
 *
 * -------------------------------------
 */
#include "functions.h"

void strings_with_substring(strings_array *data, char *substr) {
	if (!data || !substr) {
		return;
	}

	for (int i = 0; i < data->lines; i++) {
		if (strstr(data->strings[i], substr)) {
			printf("%s\n", data->strings[i]);
		}
	}
}
