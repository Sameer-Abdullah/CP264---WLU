/**
 * -------------------------------------
 * @file  queue_linked.c
 * Linked Queue Source Code File
 * -------------------------------------
 * @author Sameer Abdullah, 169065039, abdu5039@mylaurier.ca
 *
 * @version 2025-02-23
 *
 * -------------------------------------
 */
// Includes
#include "queue_linked.h"

// Functions

queue_linked* queue_initialize() {

	queue_linked *q = malloc(sizeof(queue_linked));
	if (q == NULL) {
		return NULL; // Allocation failed
	}
	q->front = NULL;
	q->rear = NULL;
	q->count = 0;
	return q;

}

void queue_free(queue_linked **source) {

	if (source == NULL || *source == NULL)
		return;

	queue_node *current = (*source)->front;
	while (current != NULL) {
		queue_node *temp = current;
		current = current->next;
		data_free(&temp->item);
		free(temp);
	}
	free(*source);
	*source = NULL;
	return;
}

bool queue_empty(const queue_linked *source) {

	return (source == NULL || source->front == NULL);
}

int queue_count(const queue_linked *source) {

	if (source == NULL)
		return 0;
	return source->count;
}

bool queue_insert(queue_linked *source, data_ptr item) {

	if (source == NULL || item == NULL)
		return false;

	// Allocate a new node.
	queue_node *node = malloc(sizeof(queue_node));
	if (node == NULL)
		return false;
	node->next = NULL;

	// Allocate memory for the data and copy it.
	node->item = malloc(sizeof(*(node->item)));
	if (node->item == NULL) {
		free(node);
		return false;
	}
	data_copy(node->item, item);

	// If the queue is empty, both front and rear point to the new node.
	if (source->rear == NULL) {
		source->front = node;
		source->rear = node;
	} else {
		// Otherwise, append to the rear and update the pointer.
		source->rear->next = node;
		source->rear = node;
	}

	source->count++;
	return true;
}

bool queue_peek(const queue_linked *source, data_ptr item) {

	if (queue_empty(source) || item == NULL)
		return false;

	data_copy(item, source->front->item);
	return true; // your code here

	return true;
}

bool queue_remove(queue_linked *source, data_ptr *item) {

	if (queue_empty(source) || item == NULL)
		return false;

	queue_node *temp = source->front;
	*item = temp->item;  // Transfer ownership of the data pointer.
	source->front = temp->next;

	// If the queue is now empty, update the rear pointer.
	if (source->front == NULL) {
		source->rear = NULL;
	}

	source->count--;
	free(temp);
	return true;
}

void queue_print(const queue_linked *source) {
	char string[DATA_STRING_SIZE];
	queue_node *current = source->front;

	while (current != NULL) {
		data_string(string, sizeof string, current->item);
		printf("%s\n", string);
		current = current->next;
	}
	return;
}

