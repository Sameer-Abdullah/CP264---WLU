var struct_n_a_m_e___s_e_t___n_o_d_e =
[
    [ "first_name", "struct_n_a_m_e___s_e_t___n_o_d_e.htm#a80c1c4360c7e9672718ccda400c8d278", null ],
    [ "last_name", "struct_n_a_m_e___s_e_t___n_o_d_e.htm#a52e89b212e8feb0215ded2e4935bbbea", null ],
    [ "next", "struct_n_a_m_e___s_e_t___n_o_d_e.htm#a954c36c72107f05c25c900b46e04460c", null ]
];